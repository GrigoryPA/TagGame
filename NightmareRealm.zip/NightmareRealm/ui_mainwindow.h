/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushRed_1;
    QPushButton *pushRed_2;
    QPushButton *pushRed_3;
    QPushButton *pushRed_4;
    QPushButton *pushYellow_3;
    QPushButton *pushYellow_4;
    QPushButton *Rock_2;
    QPushButton *Rock_1;
    QPushButton *voidButton_4;
    QPushButton *voidButton_3;
    QPushButton *voidButton_2;
    QPushButton *pushRed_5;
    QPushButton *pushYellow_1;
    QPushButton *pushYellow_5;
    QPushButton *pushYellow_2;
    QPushButton *voidButton_1;
    QPushButton *Rock_3;
    QPushButton *Rock_4;
    QPushButton *Rock_5;
    QPushButton *Rock_6;
    QPushButton *pushBlue_1;
    QPushButton *pushBlue_2;
    QPushButton *pushBlue_3;
    QPushButton *pushBlue_4;
    QPushButton *pushBlue_5;
    QPushButton *Red;
    QPushButton *Blue;
    QPushButton *Yellow;
    QPushButton *iron;
    QPushButton *iron_2;
    QPushButton *iron_3;
    QPushButton *iron_4;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(500, 550);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushRed_1 = new QPushButton(centralwidget);
        pushRed_1->setObjectName(QString::fromUtf8("pushRed_1"));
        pushRed_1->setGeometry(QRect(400, 250, 100, 100));
        QFont font;
        font.setFamily(QString::fromUtf8("MS UI Gothic"));
        font.setPointSize(24);
        font.setBold(false);
        font.setWeight(50);
        pushRed_1->setFont(font);
        pushRed_1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 105, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushRed_2 = new QPushButton(centralwidget);
        pushRed_2->setObjectName(QString::fromUtf8("pushRed_2"));
        pushRed_2->setGeometry(QRect(0, 150, 100, 100));
        pushRed_2->setFont(font);
        pushRed_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 105, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushRed_3 = new QPushButton(centralwidget);
        pushRed_3->setObjectName(QString::fromUtf8("pushRed_3"));
        pushRed_3->setGeometry(QRect(200, 250, 100, 100));
        pushRed_3->setFont(font);
        pushRed_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 105, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushRed_4 = new QPushButton(centralwidget);
        pushRed_4->setObjectName(QString::fromUtf8("pushRed_4"));
        pushRed_4->setGeometry(QRect(200, 450, 100, 100));
        pushRed_4->setFont(font);
        pushRed_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 105, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushYellow_3 = new QPushButton(centralwidget);
        pushYellow_3->setObjectName(QString::fromUtf8("pushYellow_3"));
        pushYellow_3->setGeometry(QRect(200, 150, 100, 100));
        pushYellow_3->setFont(font);
        pushYellow_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushYellow_4 = new QPushButton(centralwidget);
        pushYellow_4->setObjectName(QString::fromUtf8("pushYellow_4"));
        pushYellow_4->setGeometry(QRect(400, 450, 100, 100));
        pushYellow_4->setFont(font);
        pushYellow_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        Rock_2 = new QPushButton(centralwidget);
        Rock_2->setObjectName(QString::fromUtf8("Rock_2"));
        Rock_2->setGeometry(QRect(100, 250, 100, 100));
        Rock_2->setFont(font);
        Rock_2->setStyleSheet(QString::fromUtf8("\n"
"background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(108, 108, 108, 255), stop:0.522472 rgba(71, 71, 71, 255), stop:1 rgba(53, 53, 53, 255));\n"
"color: rgb(0, 0, 0);\n"
""));
        Rock_1 = new QPushButton(centralwidget);
        Rock_1->setObjectName(QString::fromUtf8("Rock_1"));
        Rock_1->setGeometry(QRect(100, 50, 100, 100));
        Rock_1->setFont(font);
        Rock_1->setStyleSheet(QString::fromUtf8("\n"
"background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(108, 108, 108, 255), stop:0.522472 rgba(71, 71, 71, 255), stop:1 rgba(53, 53, 53, 255));\n"
"color: rgb(0, 0, 0);\n"
""));
        voidButton_4 = new QPushButton(centralwidget);
        voidButton_4->setObjectName(QString::fromUtf8("voidButton_4"));
        voidButton_4->setGeometry(QRect(300, 350, 100, 100));
        voidButton_4->setFont(font);
        voidButton_4->setToolTipDuration(-1);
        voidButton_4->setStyleSheet(QString::fromUtf8("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:1.585, fx:0.5, fy:0.5, stop:1 rgba(255, 255, 255, 0));\n"
""));
        voidButton_3 = new QPushButton(centralwidget);
        voidButton_3->setObjectName(QString::fromUtf8("voidButton_3"));
        voidButton_3->setGeometry(QRect(300, 150, 100, 100));
        voidButton_3->setFont(font);
        voidButton_3->setToolTipDuration(-1);
        voidButton_3->setStyleSheet(QString::fromUtf8("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:1.585, fx:0.5, fy:0.5, stop:1 rgba(255, 255, 255, 0));\n"
""));
        voidButton_2 = new QPushButton(centralwidget);
        voidButton_2->setObjectName(QString::fromUtf8("voidButton_2"));
        voidButton_2->setGeometry(QRect(100, 350, 100, 100));
        voidButton_2->setFont(font);
        voidButton_2->setToolTipDuration(-1);
        voidButton_2->setStyleSheet(QString::fromUtf8("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:1.585, fx:0.5, fy:0.5, stop:1 rgba(255, 255, 255, 0));\n"
""));
        pushRed_5 = new QPushButton(centralwidget);
        pushRed_5->setObjectName(QString::fromUtf8("pushRed_5"));
        pushRed_5->setGeometry(QRect(0, 450, 100, 100));
        pushRed_5->setFont(font);
        pushRed_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 105, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushYellow_1 = new QPushButton(centralwidget);
        pushYellow_1->setObjectName(QString::fromUtf8("pushYellow_1"));
        pushYellow_1->setGeometry(QRect(400, 350, 100, 100));
        pushYellow_1->setFont(font);
        pushYellow_1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushYellow_5 = new QPushButton(centralwidget);
        pushYellow_5->setObjectName(QString::fromUtf8("pushYellow_5"));
        pushYellow_5->setGeometry(QRect(0, 250, 100, 100));
        pushYellow_5->setFont(font);
        pushYellow_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushYellow_2 = new QPushButton(centralwidget);
        pushYellow_2->setObjectName(QString::fromUtf8("pushYellow_2"));
        pushYellow_2->setGeometry(QRect(200, 50, 100, 100));
        pushYellow_2->setFont(font);
        pushYellow_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        voidButton_1 = new QPushButton(centralwidget);
        voidButton_1->setObjectName(QString::fromUtf8("voidButton_1"));
        voidButton_1->setGeometry(QRect(100, 150, 100, 100));
        voidButton_1->setFont(font);
        voidButton_1->setToolTipDuration(-1);
        voidButton_1->setStyleSheet(QString::fromUtf8("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:1.585, fx:0.5, fy:0.5, stop:1 rgba(255, 255, 255, 0));\n"
""));
        Rock_3 = new QPushButton(centralwidget);
        Rock_3->setObjectName(QString::fromUtf8("Rock_3"));
        Rock_3->setGeometry(QRect(300, 250, 100, 100));
        Rock_3->setFont(font);
        Rock_3->setStyleSheet(QString::fromUtf8("\n"
"background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(108, 108, 108, 255), stop:0.522472 rgba(71, 71, 71, 255), stop:1 rgba(53, 53, 53, 255));\n"
"color: rgb(0, 0, 0);\n"
""));
        Rock_4 = new QPushButton(centralwidget);
        Rock_4->setObjectName(QString::fromUtf8("Rock_4"));
        Rock_4->setGeometry(QRect(100, 450, 100, 100));
        Rock_4->setFont(font);
        Rock_4->setStyleSheet(QString::fromUtf8("\n"
"background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(108, 108, 108, 255), stop:0.522472 rgba(71, 71, 71, 255), stop:1 rgba(53, 53, 53, 255));\n"
"color: rgb(0, 0, 0);\n"
""));
        Rock_5 = new QPushButton(centralwidget);
        Rock_5->setObjectName(QString::fromUtf8("Rock_5"));
        Rock_5->setGeometry(QRect(300, 50, 100, 100));
        Rock_5->setFont(font);
        Rock_5->setStyleSheet(QString::fromUtf8("\n"
"background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(108, 108, 108, 255), stop:0.522472 rgba(71, 71, 71, 255), stop:1 rgba(53, 53, 53, 255));\n"
"color: rgb(0, 0, 0);\n"
""));
        Rock_6 = new QPushButton(centralwidget);
        Rock_6->setObjectName(QString::fromUtf8("Rock_6"));
        Rock_6->setGeometry(QRect(300, 450, 100, 100));
        Rock_6->setFont(font);
        Rock_6->setStyleSheet(QString::fromUtf8("\n"
"background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(108, 108, 108, 255), stop:0.522472 rgba(71, 71, 71, 255), stop:1 rgba(53, 53, 53, 255));\n"
"color: rgb(0, 0, 0);\n"
""));
        pushBlue_1 = new QPushButton(centralwidget);
        pushBlue_1->setObjectName(QString::fromUtf8("pushBlue_1"));
        pushBlue_1->setGeometry(QRect(400, 150, 100, 100));
        pushBlue_1->setFont(font);
        pushBlue_1->setStyleSheet(QString::fromUtf8("background-color: rgb(105, 205, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushBlue_2 = new QPushButton(centralwidget);
        pushBlue_2->setObjectName(QString::fromUtf8("pushBlue_2"));
        pushBlue_2->setGeometry(QRect(200, 350, 100, 100));
        pushBlue_2->setFont(font);
        pushBlue_2->setStyleSheet(QString::fromUtf8("background-color: rgb(105, 205, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushBlue_3 = new QPushButton(centralwidget);
        pushBlue_3->setObjectName(QString::fromUtf8("pushBlue_3"));
        pushBlue_3->setGeometry(QRect(0, 50, 100, 100));
        pushBlue_3->setFont(font);
        pushBlue_3->setStyleSheet(QString::fromUtf8("background-color: rgb(105, 205, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushBlue_4 = new QPushButton(centralwidget);
        pushBlue_4->setObjectName(QString::fromUtf8("pushBlue_4"));
        pushBlue_4->setGeometry(QRect(400, 50, 100, 100));
        pushBlue_4->setFont(font);
        pushBlue_4->setStyleSheet(QString::fromUtf8("background-color: rgb(105, 205, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        pushBlue_5 = new QPushButton(centralwidget);
        pushBlue_5->setObjectName(QString::fromUtf8("pushBlue_5"));
        pushBlue_5->setGeometry(QRect(0, 350, 100, 100));
        pushBlue_5->setFont(font);
        pushBlue_5->setStyleSheet(QString::fromUtf8("background-color: rgb(105, 205, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        Red = new QPushButton(centralwidget);
        Red->setObjectName(QString::fromUtf8("Red"));
        Red->setGeometry(QRect(0, 10, 100, 20));
        Red->setFont(font);
        Red->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 105, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        Blue = new QPushButton(centralwidget);
        Blue->setObjectName(QString::fromUtf8("Blue"));
        Blue->setGeometry(QRect(400, 10, 100, 20));
        Blue->setFont(font);
        Blue->setStyleSheet(QString::fromUtf8("background-color: rgb(105, 205, 255);\n"
"color: rgb(0, 0, 0);\n"
""));
        Yellow = new QPushButton(centralwidget);
        Yellow->setObjectName(QString::fromUtf8("Yellow"));
        Yellow->setGeometry(QRect(200, 10, 100, 20));
        Yellow->setFont(font);
        Yellow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 105);\n"
"color: rgb(0, 0, 0);\n"
""));
        iron = new QPushButton(centralwidget);
        iron->setObjectName(QString::fromUtf8("iron"));
        iron->setGeometry(QRect(100, 10, 100, 20));
        iron->setFont(font);
        iron->setStyleSheet(QString::fromUtf8("background-color: rgb(33, 33, 33);\n"
"color: rgb(0, 0, 0);\n"
""));
        iron_2 = new QPushButton(centralwidget);
        iron_2->setObjectName(QString::fromUtf8("iron_2"));
        iron_2->setGeometry(QRect(300, 10, 100, 20));
        iron_2->setFont(font);
        iron_2->setStyleSheet(QString::fromUtf8("background-color: rgb(33, 33, 33);\n"
"color: rgb(0, 0, 0);\n"
""));
        iron_3 = new QPushButton(centralwidget);
        iron_3->setObjectName(QString::fromUtf8("iron_3"));
        iron_3->setGeometry(QRect(0, 30, 500, 20));
        iron_3->setFont(font);
        iron_3->setStyleSheet(QString::fromUtf8("background-color: rgb(33, 33, 33);\n"
"color: rgb(0, 0, 0);\n"
""));
        iron_4 = new QPushButton(centralwidget);
        iron_4->setObjectName(QString::fromUtf8("iron_4"));
        iron_4->setGeometry(QRect(0, 0, 500, 10));
        iron_4->setFont(font);
        iron_4->setStyleSheet(QString::fromUtf8("background-color: rgb(33, 33, 33);\n"
"color: rgb(0, 0, 0);\n"
""));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushRed_1->setText(QString());
        pushRed_2->setText(QString());
        pushRed_3->setText(QString());
        pushRed_4->setText(QString());
        pushYellow_3->setText(QString());
        pushYellow_4->setText(QString());
        Rock_2->setText(QString());
        Rock_1->setText(QString());
        voidButton_4->setText(QString());
        voidButton_3->setText(QString());
        voidButton_2->setText(QString());
        pushRed_5->setText(QString());
        pushYellow_1->setText(QString());
        pushYellow_5->setText(QString());
        pushYellow_2->setText(QString());
        voidButton_1->setText(QString());
        Rock_3->setText(QString());
        Rock_4->setText(QString());
        Rock_5->setText(QString());
        Rock_6->setText(QString());
        pushBlue_1->setText(QString());
        pushBlue_2->setText(QString());
        pushBlue_3->setText(QString());
        pushBlue_4->setText(QString());
        pushBlue_5->setText(QString());
        Red->setText(QString());
        Blue->setText(QString());
        Yellow->setText(QString());
        iron->setText(QString());
        iron_2->setText(QString());
        iron_3->setText(QString());
        iron_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
